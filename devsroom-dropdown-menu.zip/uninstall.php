<?php
/**
 * Uninstall routine for Devsroom Dropdown Menu.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// No options are currently stored. This file is intentionally minimal.
